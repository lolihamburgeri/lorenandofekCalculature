package com.example.ofekandlorencalculature;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView textViewResult;
    int num1;
    char ch;
    int num2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewResult = (TextView) findViewById(R.id.textViewResult);
        textViewResult.setText("");
    }

    public void funcNumButton(View view) {

        Button button = (Button) view;

        String str = button.getText().toString();

        //textViewResult.setText(str);
        textViewResult.append(str);

    }

    public void funcOpp(View view) {

        Button button = (Button)view;

        ch = button.getText().charAt(0);

        String str = textViewResult.getText().toString();

        num1 = Integer.parseInt(str);

        textViewResult.setText("");
    }

    public void funcEqual(View view) {

        String str = textViewResult.getText().toString();

        num2 = Integer.parseInt(str);

        int result = 0;

        switch(ch){

            case '+':
                result = num1 + num2;
                break;

            case '-':
                result = num1 - num2;
                break;

            case '*':
                result = num1 * num2;
                break;

            case '/':
                result = num1 / num2;
                break;
        }
        textViewResult.setText(result + "");

    }
}